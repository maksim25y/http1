create function audit_function() returns trigger
    language plpgsql
as
$$
    BEGIN
    INSERT INTO audit(id,table_name,date)
    VALUES (new.id,tg_table_name,now());
    RETURN NULL;
    END;
$$;

alter function audit_function() owner to postgres;

